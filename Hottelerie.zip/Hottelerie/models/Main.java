package models;

import controllers.AdminController;
import views.RoomManagementView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        GestionChambres gestionChambres = new GestionChambres();
        try {
            gestionChambres.loadChambres(); // Load existing rooms if any
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Define the types and price ranges
        String[] types = {"Luxe", "Normal", "Suite"};
        double[] prices = {23000, 15000, 30000};

        // Generate 30 rooms
        for (int i = 1; i <= 30; i++) {
            String type = types[i % 3]; // Rotate through the types
            double price = prices[i % 3]; // Rotate through the prices
            Chambre chambre = new Chambre(i, type, price);
            gestionChambres.ajouterChambre(chambre);
        }

        // Save the rooms
        try {
            gestionChambres.saveChambres();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Initialize other necessary components
        GestionReservations gestionReservations = new GestionReservations();
        AdminController adminController = new AdminController(gestionChambres, gestionReservations);

        // Show the Room Management View
        RoomManagementView roomManagementView = new RoomManagementView(adminController);
        roomManagementView.setVisible(true);
    }
}
