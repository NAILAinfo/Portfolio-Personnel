package models;

public class Utilisateur {
    private String username;
    private String password;
    private String role;
    private String emailOrPhone;
    private String dateOfBirth;
    private String country;
    private String sex;

    // Constructor for all fields
    public Utilisateur(String username, String password, String role, String emailOrPhone, String dateOfBirth, String country, String sex) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.emailOrPhone = emailOrPhone;
        this.dateOfBirth = dateOfBirth;
        this.country = country;
        this.sex = sex;
    }

    // Constructor for minimal fields (e.g., Admin)
    public Utilisateur(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public String getEmailOrPhone() {
        return emailOrPhone;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getCountry() {
        return country;
    }



    public void setRole(String role) {
        this.role = role;
    }

    public String getSex() {
        return sex;
    }

    public String getEmail() {
        return emailOrPhone; // Assuming emailOrPhone contains the email
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
