package models;

import java.io.*;
import java.util.HashMap;

public class GestionUtilisateurs {
    private HashMap<String, Utilisateur> utilisateurs;
    private static final String USERS_FILENAME = "users.dat";

    public GestionUtilisateurs() {
        this.utilisateurs = new HashMap<>();
    }

    public void ajouterUtilisateur(Utilisateur utilisateur) {
        utilisateurs.put(utilisateur.getUsername(), utilisateur);
    }

    public Utilisateur getUtilisateur(String username) {
        return utilisateurs.get(username);
    }

    public boolean authenticate(String username, String password) {
        Utilisateur utilisateur = utilisateurs.get(username);
        if (utilisateur != null) {
            return utilisateur.getPassword().equals(password);
        }
        return false;
    }

    public void loadUsers() throws IOException, ClassNotFoundException {
        File file = new File(USERS_FILENAME);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                utilisateurs = (HashMap<String, Utilisateur>) ois.readObject();
            }
        } else {
            utilisateurs = new HashMap<>();
            saveUsers(); // Create an empty file if it does not exist
        }
    }

    public void saveUsers() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILENAME))) {
            oos.writeObject(utilisateurs);
        }
    }
}
