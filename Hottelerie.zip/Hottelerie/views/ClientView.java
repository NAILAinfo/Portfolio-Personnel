package views;

import controllers.ClientController;
import models.GestionReservations;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClientView extends JFrame {
    private ClientController clientController;
    private JButton demanderReservationButton;
    private JButton modifierReservationButton;
    private JButton annulerReservationButton;
    // Autres composants de l'interface graphique...

    public ClientView(ClientController clientController) {
        this.clientController = new ClientController(new GestionReservations());
        setTitle("Client Panel");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        add(panel);
        placeComponents(panel);

        demanderReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logique pour demander une réservation
            }
        });

        modifierReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logique pour modifier une réservation
            }
        });

        annulerReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logique pour annuler une réservation
            }
        });
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        demanderReservationButton = new JButton("Demander Réservation");
        demanderReservationButton.setBounds(10, 20, 160, 25);
        panel.add(demanderReservationButton);

        modifierReservationButton = new JButton("Modifier Réservation");
        modifierReservationButton.setBounds(10, 60, 160, 25);
        panel.add(modifierReservationButton);

        annulerReservationButton = new JButton("Annuler Réservation");
        annulerReservationButton.setBounds(10, 100, 160, 25);
        panel.add(annulerReservationButton);

        // Autres composants...
    }

    public static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            Color color1 = new Color(70, 130, 180);
            Color color2 = new Color(230, 230, 250);
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, height, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, width, height);
        }
    }
}
