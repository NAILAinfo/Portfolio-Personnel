package controllers;

import models.GestionReservations;
import models.Reservation;

public class ClientController {
    private GestionReservations gestionReservations;

    public ClientController(GestionReservations gestionReservations) {
        this.gestionReservations = gestionReservations;
    }

    public void demanderReservation(Reservation reservation) {
        gestionReservations.ajouterReservation(reservation);
    }

    public void modifierReservation(int id, Reservation reservation) throws Exception {
        Reservation existante = gestionReservations.getReservation(id);
        if (existante == null) {
            throw new Exception("La réservation n'existe pas.");
        }
        gestionReservations.modifierReservation(id, reservation);
    }

}
