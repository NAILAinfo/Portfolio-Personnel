package controllers;

import models.GestionUtilisateurs;
import models.Utilisateur;

import java.io.IOException;

public class AuthController {
    private GestionUtilisateurs gestionUtilisateurs;

    public AuthController(GestionUtilisateurs gestionUtilisateurs) {
        this.gestionUtilisateurs = gestionUtilisateurs;
        try {
            this.gestionUtilisateurs.loadUsers();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void signup(Utilisateur utilisateur) {
        gestionUtilisateurs.ajouterUtilisateur(utilisateur);
        try {
            gestionUtilisateurs.saveUsers();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Utilisateur getUserByUsername(String username) {
        return gestionUtilisateurs.getUtilisateur(username);
    }

    public Utilisateur login(String username, String password) throws Exception {
        Utilisateur user = gestionUtilisateurs.getUtilisateur(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        } else {
            throw new Exception("Invalid username or password");
        }
    }
}
