package controllers;

import models.Chambre;
import models.GestionChambres;
import models.GestionReservations;
import models.Reservation;

import java.io.IOException;
import java.util.HashMap;

public class AdminController {
    private GestionChambres gestionChambres;
    private GestionReservations gestionReservations;

    public AdminController(GestionChambres gestionChambres, GestionReservations gestionReservations) {
        this.gestionChambres = gestionChambres;
        this.gestionReservations = gestionReservations;
        try {
            this.gestionChambres.loadChambres();
            this.gestionReservations.loadReservations();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public GestionChambres getGestionChambres() {
        return gestionChambres;
    }

    public GestionReservations getGestionReservations() {
        return gestionReservations;
    }

    public void addReservation(Reservation reservation) {
        gestionReservations.ajouterReservation(reservation);
        try {
            gestionReservations.saveReservations();
        } catch (IOException e) {
            e.printStackTrace();
        }
    } public void ajouterChambre(Chambre chambre) throws IOException {
        if (chambre == null) {
            throw new IllegalArgumentException("La chambre ne peut pas être null.");
        }

        gestionChambres.ajouterChambre(chambre);
        gestionChambres.saveChambres();
    }

    public void acceptReservation(int reservationId) {
        gestionReservations.acceptReservation(reservationId);
        try {
            gestionReservations.saveReservations();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void declineReservation(int reservationId) {
        gestionReservations.declineReservation(reservationId);
        try {
            gestionReservations.saveReservations();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HashMap<Integer, Reservation> getReservations() {
        return gestionReservations.getAllReservations();
    }

    public void supprimerChambre(int numero) {
        getGestionChambres().supprimerChambre(numero);
    }

    public void saveChambres() throws IOException {
        gestionChambres.saveChambres();
    }



    public void updateChambreStatus(int numero, String status) {
        Chambre chambre = getGestionChambres().getChambre(numero);
        if (chambre != null) {
            chambre.setStatus(status);
            try {
                saveChambres();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void loadChambres() throws IOException, ClassNotFoundException {
        gestionChambres.loadChambres();
    }
}
